let falhasConsecutivas = 0;
let ultimoEnvio = 0;

function atualizarBadgeVerde() {
  chrome.action.setBadgeText({ text: "✔" });
  chrome.action.setBadgeBackgroundColor({ color: "#00C853" });
}

function atualizarBadgeVermelho() {
  chrome.action.setBadgeText({ text: "X" });
  chrome.action.setBadgeBackgroundColor({ color: "#FF0000" });
}

function atualizarBadgeAmarelo() {
  chrome.action.setBadgeText({ text: "!" });
  chrome.action.setBadgeBackgroundColor({ color: "#FFD600" });
}

function armazenarSessao(sessionData) {
  chrome.storage.local.set({
    nikeSession: sessionData,
    sessionTimestamp: Date.now(),
    ultimoEmail: sessionData.email,
    ultimaHora: new Date().toLocaleTimeString("pt-BR", { hour12: false })
  });
}

async function solicitarSessaoDeUmaAbaNike() {
  const abas = await chrome.tabs.query({});
  const nikeAbas = abas.filter(tab => tab.url && tab.url.includes("nike.com.br"));
  
  if (nikeAbas.length === 0) {
    atualizarBadgeVermelho();
    return;
  }
  
  try {
    await chrome.scripting.executeScript({
      target: { tabId: nikeAbas[0].id },
      func: () => {
        fetch("https://www.nike.com.br/api/auth/session", {
          method: "GET",
          credentials: "include"
        })
        .then(res => res.json())
        .then(data => {
          try {
            if (!data || Object.keys(data).length === 0) {
              chrome.runtime.sendMessage({ vazio: true });
              return;
            }
            if (data.accessToken && data.user?.email && data.x_client_token) {
              chrome.runtime.sendMessage({
                token: data.accessToken,
                email: data.user.email,
                accessTokenExpires: data.accessTokenExpires,
                expires: data.expires ?? null,
                clientToken: data.x_client_token
              });
            } else {
              chrome.runtime.sendMessage({ vazio: true });
            }
          } catch (e) {}
        })
        .catch(err => {
          try {
            chrome.runtime.sendMessage({ erro: true, msg: err.toString() });
          } catch (e) {}
        });
      }
    });
  } catch (err) {
    console.warn("Falha ao executar script na aba da Nike:", err.message);
    atualizarBadgeVermelho();
  }
}

async function verificarSessao() {
  const dados = await chrome.storage.local.get(['nikeSession', 'sessionTimestamp']);
  if (dados.nikeSession && dados.sessionTimestamp) {
    const agora = Date.now();
    const expira = new Date(dados.nikeSession.accessTokenExpires).getTime();
    
    if (expira > agora) {
      atualizarBadgeVerde();
      return dados.nikeSession;
    }
  }
  
  return solicitarSessaoDeUmaAbaNike();
}

chrome.runtime.onMessage.addListener((message) => {
  if (message.token && message.email) {
    armazenarSessao({
      email: message.email,
      token: message.token,
      accessTokenExpires: message.accessTokenExpires,
      expires: message.expires,
      clientToken: message.clientToken
    });
    
    fetch("https://atmosbot.io/api/sync-status", {
      method: "POST",
      headers: { "Content-Type": "application/json" },
      body: JSON.stringify({
        email: message.email,
        token: message.token,
        accessTokenExpires: message.accessTokenExpires,
        expires: message.expires,
        clientToken: message.clientToken
      })
    }).then(response => {
      if (!response.ok) {
        falhasConsecutivas++;
        if (falhasConsecutivas >= 3) atualizarBadgeVermelho();
      } else {
        falhasConsecutivas = 0;
        ultimoEnvio = Date.now();
        atualizarBadgeVerde();
        chrome.storage.local.set({
          ultimoEmail: message.email,
          ultimaHora: new Date().toLocaleTimeString("pt-BR", { hour12: false })
        });
      }
    }).catch(() => {
      falhasConsecutivas++;
      if (falhasConsecutivas >= 3) atualizarBadgeVermelho();
    });
  } else if (message.vazio) {
    atualizarBadgeAmarelo();
  } else if (message.erro) {
    falhasConsecutivas++;
    if (falhasConsecutivas >= 3) atualizarBadgeVermelho();
  }
});

chrome.tabs.onUpdated.addListener((tabId, changeInfo, tab) => {
  if (changeInfo.status === 'complete' && tab.url && tab.url.includes('nike.com.br')) {
    setTimeout(() => solicitarSessaoDeUmaAbaNike(), 2000);
  }
});

chrome.runtime.onStartup.addListener(() => {
  setTimeout(() => verificarSessao(), 5000);
});

chrome.runtime.onInstalled.addListener(() => {
  setTimeout(() => verificarSessao(), 3000);
});

setInterval(solicitarSessaoDeUmaAbaNike, 30000);
verificarSessao();