document.addEventListener("DOMContentLoaded", () => {
  chrome.storage.local.get(["ultimoEmail", "ultimaHora"], (dados) => {
    document.getElementById("email").textContent = dados.ultimoEmail || "-";
    document.getElementById("hora").textContent = dados.ultimaHora || "-";
  });
});