chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (message === "coletarSessaoNike") {
    fetch("https://www.nike.com.br/api/auth/session", {
      method: "GET",
      credentials: "include"
    })
      .then(res => res.json())
      .then(data => {
        if (data.accessToken && data.user?.email && data.x_client_token) {
          chrome.runtime.sendMessage({
            token: data.accessToken,
            email: data.user.email,
            accessTokenExpires: data.accessTokenExpires,
            expires: data.expires,
            clientToken: data.x_client_token
          });
        } else {
          chrome.runtime.sendMessage({ vazio: true });
        }
      })
      .catch(err => {
        chrome.runtime.sendMessage({ erro: true, msg: err.toString() });
      });
  }
});
